
// Fix: Import React types to resolve JSX namespace error and use React.ReactNode for broader compatibility.
import type React from 'react';

export enum ImageStatus {
    Pending = 'pending',
    Success = 'success',
    Failed = 'failed',
}

export interface Prompt {
    id: string;
    base: string;
    background?: string;
    clothing?: string;
}

export interface GeneratedImage {
    id: string;
    status: ImageStatus;
    imageUrl: string | null;
}

export type TemplateId = 'decades' | 'styleLookbook' | 'headshots' | 'eightiesMall' | 'impossibleSelfies' | 'hairStyler' | 'figurines' | 'swimsuitEdition' | null;

export interface Template {
    name: string;
    icon: React.ReactNode;
    description: string;
    prompts: Prompt[];
    isPolaroid?: boolean;
    styles?: string[];
}