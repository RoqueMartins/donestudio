
import React from 'react';
import { Template, TemplateId } from './types';
import { IconDecades, IconLookbook, IconHeadshot, IconMall, IconSelfie, IconHair, IconFigurine, IconSwimsuit } from './components/icons';

export const TEMPLATES: Record<Exclude<TemplateId, null>, Template> = {
    decades: {
        name: "Decades",
        icon: <IconDecades />,
        description: "Travel through time and see yourself in different eras.",
        isPolaroid: true,
        prompts: [
            { id: "The 20s", base: "A 1920s-style portrait of a person" },
            { id: "The 50s", base: "A 1950s-style portrait of a person" },
            { id: "The 70s", base: "A 1970s-style portrait of a person" },
            { id: "The 90s", base: "A 1990s-style portrait of a person" },
            { id: "The Future", base: "A futuristic, cyberpunk-style portrait of a person" },
        ],
    },
    styleLookbook: {
        name: "Style Lookbook",
        icon: <IconLookbook />,
        description: "Try on different fashion styles and create your own lookbook.",
        prompts: [
            { id: "Look 1", base: "A full-body fashion lookbook photo of a person wearing a stylish outfit." },
            { id: "Look 2", base: "A chic, street-style photo of a person in a fashionable outfit." },
            { id: "Look 3", base: "An editorial fashion photo of a person posing in a high-fashion outfit." },
            { id: "Look 4", base: "A casual, everyday fashion photo of a person in a comfortable yet stylish outfit." },
        ],
        styles: ['Minimalist', 'Bohemian', 'Streetwear', 'Vintage', 'Grunge', 'Athleisure'],
    },
    headshots: {
        name: "Headshots",
        icon: <IconHeadshot />,
        description: "Generate professional headshots for your profile.",
        prompts: [
            // Fix: Add missing 'base' property to conform to the 'Prompt' type.
            { id: "Modern Office", base: "", background: "in a modern, bright office with blurred background", clothing: "wearing a professional blazer" },
            // Fix: Add missing 'base' property to conform to the 'Prompt' type.
            { id: "Studio Gray", base: "", background: "against a solid medium-gray studio background", clothing: "wearing a smart business-casual top" },
            // Fix: Add missing 'base' property to conform to the 'Prompt' type.
            { id: "Outdoors", base: "", background: "outdoors with soft, natural light and blurred greenery", clothing: "wearing a stylish, professional jacket" },
            // Fix: Add missing 'base' property to conform to the 'Prompt' type.
            { id: "Creative Space", base: "", background: "in a creative, industrial-style studio with interesting textures", clothing: "wearing a unique but professional outfit" },
        ],
    },
    eightiesMall: {
        name: "'80s Mall",
        icon: <IconMall />,
        description: "A totally tubular photoshoot straight from the mall.",
        prompts: [
            { id: "Laser Show", base: "An over-the-top 80s mall glamour shot of a person with a laser background." },
            { id: "School Picture Day", base: "An awkward 80s school picture day photo of a person." },
            { id: "Totally Rad", base: "A classic 80s mall photoshoot of a person, looking rad." },
            { id: "The Couple", base: "A cheesy 80s mall couple-style photo, but with only one person." },
        ],
    },
    impossibleSelfies: {
        name: "Impossible Selfies",
        icon: <IconSelfie />,
        description: "Snap selfies in places you've only dreamed of.",
        isPolaroid: true,
        prompts: [
            { id: "On Everest", base: "A selfie of a person on top of Mount Everest, windblown and triumphant." },
            { id: "The Moon", base: "A selfie of a person on the moon, with the Earth in the background." },
            { id: "With Dinosaurs", base: "A selfie of a person narrowly escaping a T-Rex in a lush jungle." },
            { id: "Deep Sea", base: "A selfie of a person in a vintage diving suit exploring a vibrant coral reef." },
            { id: "Ancient Rome", base: "A selfie of a person in front of the Colosseum in ancient Rome." },
        ],
    },
    hairStyler: {
        name: "Hair Styler",
        icon: <IconHair />,
        description: "Experiment with new hairstyles and colors.",
        prompts: [
            { id: "Pixie Cut", base: "A person with a chic pixie cut." },
            { id: "Long & Wavy", base: "A person with long, wavy hair." },
            { id: "Bob", base: "A person with a stylish bob haircut." },
            { id: "Curly Shag", base: "A person with a curly shag hairstyle." },
            { id: "Braids", base: "A person with intricate box braids." },
            { id: "Slick Back", base: "A person with a slicked-back, wet look hairstyle." },
        ],
    },
    figurines: {
        name: "Figurines",
        icon: <IconFigurine />,
        description: "See yourself as a detailed, miniature collectible figure.",
        prompts: [
            { id: "Action Figure", base: "A highly detailed action figure of a person inside its original packaging." },
            { id: "Funko Pop", base: "A vinyl Funko Pop style collectible figurine of a person, inside a collectible box." },
            { id: "Claymation", base: "A claymation-style figurine of a person on a small, detailed set." },
            { id: "Porcelain Doll", base: "An old-fashioned porcelain doll version of a person with intricate clothing." },
        ],
    },
    swimsuitEdition: {
        name: "Swimsuit Edition",
        icon: <IconSwimsuit />,
        description: "Your very own iconic beachside photoshoot.",
        prompts: [
            { id: "Tropical Paradise", base: "A person in a stylish swimsuit posing on a tropical beach with turquoise water." },
            { id: "Poolside Glam", base: "A person in a glamorous one-piece swimsuit lounging by a luxury infinity pool." },
            { id: "Rocky Coast", base: "A person in a sporty swimsuit on a dramatic, rocky coastline at sunset." },
            { id: "Vintage Beach", base: "A person in a retro-style high-waisted swimsuit on a crowded beach, 1960s photo style." },
        ]
    }
};