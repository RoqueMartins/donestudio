
import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    primary?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ children, primary, className, ...props }) => {
    const baseClasses = "px-6 py-3 rounded-xl font-semibold transition-all duration-300 focus:outline-none focus:ring-4 disabled:opacity-50 disabled:cursor-not-allowed transform hover:-translate-y-0.5 active:translate-y-0 shadow-lg";
    
    const primaryClasses = "bg-yellow-400 text-black hover:bg-yellow-300 focus:ring-yellow-400/50 disabled:hover:bg-yellow-400";
    const defaultClasses = "bg-gray-700 text-white hover:bg-gray-600 focus:ring-gray-600/50 disabled:hover:bg-gray-700";

    const combinedClasses = `${baseClasses} ${primary ? primaryClasses : defaultClasses} ${className || ''}`;

    return (
        <button className={combinedClasses} {...props}>
            {children}
        </button>
    );
};
