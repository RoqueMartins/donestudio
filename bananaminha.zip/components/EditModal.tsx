
import React, { useState } from 'react';
// @ts-ignore
import { AnimatePresence, motion } from 'framer-motion';
import { Button } from './Button';
import { IconX, IconWand } from './icons';
import { editImage } from '../services/geminiService';

interface EditModalProps {
    isOpen: boolean;
    onClose: () => void;
    imageToEdit: { url: string; index: number } | null;
    onConfirmEdit: (newImageUrl: string, index: number) => void;
}

export const EditModal: React.FC<EditModalProps> = ({ isOpen, onClose, imageToEdit, onConfirmEdit }) => {
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async () => {
        if (!prompt || !imageToEdit) return;
        setIsLoading(true);
        setError(null);
        try {
            const [header, base64Data] = imageToEdit.url.split(',');
            const mimeType = header.match(/:(.*?);/)?.[1] || 'image/png';
            const newImageUrl = await editImage(base64Data, mimeType, prompt);
            onConfirmEdit(newImageUrl, imageToEdit.index);
        } catch (err) {
            setError("Sorry, we couldn't edit that image. Please try again.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <AnimatePresence>
            {isOpen && imageToEdit && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
                    onClick={onClose}
                >
                    <motion.div
                        initial={{ scale: 0.9, y: 20 }}
                        animate={{ scale: 1, y: 0 }}
                        exit={{ scale: 0.9, y: 20 }}
                        className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-2xl p-6 shadow-2xl"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="flex justify-between items-center mb-4">
                            <h2 className="text-2xl font-bold text-white">Edit Image</h2>
                            <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700 transition-colors"><IconX /></button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <img src={imageToEdit.url} alt="Image to edit" className="w-full aspect-square object-cover rounded-lg" />
                            <div className="flex flex-col">
                                <label htmlFor="edit-prompt" className="text-gray-400 mb-2">Describe your edit:</label>
                                <textarea
                                    id="edit-prompt"
                                    value={prompt}
                                    onChange={(e) => setPrompt(e.target.value)}
                                    placeholder="e.g., 'add sunglasses', 'make it black and white', 'turn the background into a forest'"
                                    className="w-full flex-grow bg-gray-800 border border-gray-600 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-yellow-400 text-white resize-none"
                                />
                                {error && <p className="text-red-400 text-sm mt-2">{error}</p>}
                                <Button onClick={handleSubmit} primary disabled={isLoading || !prompt} className="mt-4 w-full">
                                    {isLoading ? (
                                        <div className="flex items-center justify-center gap-2">
                                            <div className="animate-spin rounded-full h-5 w-5 border-t-2 border-b-2 border-black"></div>
                                            <span>Editing...</span>
                                        </div>
                                    ) : (
                                        <div className="flex items-center justify-center gap-2"><IconWand /><span>Apply Edit</span></div>
                                    )}
                                </Button>
                            </div>
                        </div>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};
