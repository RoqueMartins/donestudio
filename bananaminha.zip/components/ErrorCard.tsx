
import React from 'react';
import { Button } from './Button';
import { IconAlert, IconRefresh } from './icons';

interface ErrorCardProps {
    era: string;
    onRegenerate: () => void;
    isPolaroid?: boolean;
    showLabel?: boolean;
}

export const ErrorCard: React.FC<ErrorCardProps> = ({ era, onRegenerate, isPolaroid, showLabel }) => {
    const cardContent = (
        <div className="w-full aspect-square bg-gray-800 border-4 border-dashed border-red-500/50 rounded-lg flex flex-col items-center justify-center p-4 text-center">
            <IconAlert className="w-12 h-12 text-red-400 mb-4" />
            <p className="text-red-300 font-semibold mb-4">Generation Failed</p>
            <Button onClick={onRegenerate}>
                <div className="flex items-center gap-2"><IconRefresh/><span>Try Again</span></div>
            </Button>
        </div>
    );
    
    if (isPolaroid) {
        return (
            <div className="bg-white p-4 pb-16 rounded-lg shadow-xl transform rotate-[-3deg] transition-transform hover:rotate-[-1deg] hover:scale-105">
                {cardContent}
                {showLabel && <p className="absolute bottom-6 left-0 right-0 text-center font-caveat text-3xl text-gray-800">{era}</p>}
            </div>
        );
    }

    return (
        <div className="relative group">
            {cardContent}
            {showLabel && <p className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-gray-900 px-3 py-1 text-sm rounded-md text-white font-semibold whitespace-nowrap">{era}</p>}
        </div>
    );
};
