
import React, { useState, useRef, useEffect } from 'react';
// @ts-ignore
import { motion, AnimatePresence } from 'framer-motion';
import { IconDownload, IconRefresh, IconWand, IconSparkles, IconChevronDown } from './icons';

interface PhotoDisplayProps {
    era: string;
    imageUrl: string;
    onDownload: (imageUrl: string, era: string, ratio: '1:1' | '9:16') => void;
    onRegenerate: () => void;
    onEdit: (imageUrl: string, index: number) => void;
    onUpscale: (imageUrl: string, index: number, resolution: '2K' | '4K') => void;
    isPolaroid?: boolean;
    index: number;
    showLabel?: boolean;
}

const ActionButton: React.FC<{ onClick: () => void, children: React.ReactNode, hasMenu?: boolean }> = ({ onClick, children, hasMenu }) => (
    <button
        onClick={onClick}
        className="flex-1 bg-black/50 backdrop-blur-md text-white py-2 px-2 rounded-lg text-xs font-semibold hover:bg-black/80 transition-colors flex items-center justify-center gap-1.5"
    >
        {children}
        {hasMenu && <IconChevronDown className="w-3 h-3"/>}
    </button>
);

export const PhotoDisplay: React.FC<PhotoDisplayProps> = ({ era, imageUrl, onDownload, onRegenerate, onEdit, onUpscale, isPolaroid, index, showLabel }) => {
    const [isDownloadMenuOpen, setDownloadMenuOpen] = useState(false);
    const [isUpscaleMenuOpen, setUpscaleMenuOpen] = useState(false);
    const downloadRef = useRef<HTMLDivElement>(null);
    const upscaleRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (downloadRef.current && !downloadRef.current.contains(event.target as Node)) setDownloadMenuOpen(false);
            if (upscaleRef.current && !upscaleRef.current.contains(event.target as Node)) setUpscaleMenuOpen(false);
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const cardContent = (
        <div className="relative w-full aspect-square group overflow-hidden rounded-lg">
            <img src={imageUrl} alt={era} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <div className="absolute bottom-0 left-0 right-0 p-3 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                <div className="flex gap-2 justify-center">
                    <div className="relative" ref={downloadRef}>
                        <ActionButton onClick={() => setDownloadMenuOpen(prev => !prev)} hasMenu><IconDownload/> Download</ActionButton>
                        <AnimatePresence>
                        {isDownloadMenuOpen && (
                            <motion.div 
                                initial={{ opacity: 0, scale: 0.9, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 10 }}
                                className="absolute bottom-full mb-2 w-full bg-gray-800 rounded-md p-1 shadow-lg border border-gray-700">
                                <button onClick={() => { onDownload(imageUrl, era, '1:1'); setDownloadMenuOpen(false); }} className="block w-full text-left text-xs px-2 py-1.5 hover:bg-yellow-400/20 rounded">Square (1:1)</button>
                                <button onClick={() => { onDownload(imageUrl, era, '9:16'); setDownloadMenuOpen(false); }} className="block w-full text-left text-xs px-2 py-1.5 hover:bg-yellow-400/20 rounded">Portrait (9:16)</button>
                            </motion.div>
                        )}
                        </AnimatePresence>
                    </div>
                    <ActionButton onClick={() => onRegenerate()}><IconRefresh/> Regenerate</ActionButton>
                    <ActionButton onClick={() => onEdit(imageUrl, index)}><IconWand/> Edit</ActionButton>
                    <div className="relative" ref={upscaleRef}>
                        <ActionButton onClick={() => setUpscaleMenuOpen(prev => !prev)} hasMenu><IconSparkles/> Upscale</ActionButton>
                         <AnimatePresence>
                        {isUpscaleMenuOpen && (
                            <motion.div 
                                initial={{ opacity: 0, scale: 0.9, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9, y: 10 }}
                                className="absolute bottom-full mb-2 w-full bg-gray-800 rounded-md p-1 shadow-lg border border-gray-700">
                                <button onClick={() => { onUpscale(imageUrl, index, '2K'); setUpscaleMenuOpen(false); }} className="block w-full text-left text-xs px-2 py-1.5 hover:bg-yellow-400/20 rounded">to 2K</button>
                                <button onClick={() => { onUpscale(imageUrl, index, '4K'); setUpscaleMenuOpen(false); }} className="block w-full text-left text-xs px-2 py-1.5 hover:bg-yellow-400/20 rounded">to 4K</button>
                            </motion.div>
                        )}
                        </AnimatePresence>
                    </div>
                </div>
            </div>
        </div>
    );
    
    if (isPolaroid) {
        return (
             <div className="bg-white p-4 pb-16 rounded-lg shadow-xl transform rotate-[-3deg] transition-transform hover:rotate-[-1deg] hover:scale-105">
                {cardContent}
                {showLabel && <p className="absolute bottom-6 left-0 right-0 text-center font-caveat text-3xl text-gray-800">{era}</p>}
            </div>
        );
    }

    return (
        <div className="relative">
            {cardContent}
            {showLabel && <p className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-gray-900 px-3 py-1 text-sm rounded-md text-white font-semibold whitespace-nowrap">{era}</p>}
        </div>
    );
};
