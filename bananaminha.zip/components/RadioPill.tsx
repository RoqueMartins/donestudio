
import React from 'react';

interface RadioPillProps extends React.InputHTMLAttributes<HTMLInputElement> {
    label: string;
}

export const RadioPill: React.FC<RadioPillProps> = ({ label, ...props }) => {
    return (
        <div>
            <input type="radio" id={props.name + label} className="hidden peer" {...props} />
            <label
                htmlFor={props.name + label}
                className="cursor-pointer px-4 py-2 text-sm rounded-full transition-colors font-semibold bg-gray-800 text-gray-300 peer-checked:bg-yellow-400 peer-checked:text-black hover:bg-gray-700"
            >
                {label}
            </label>
        </div>
    );
};
