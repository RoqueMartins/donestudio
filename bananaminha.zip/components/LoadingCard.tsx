
import React from 'react';

interface LoadingCardProps {
    isPolaroid?: boolean;
    showLabel?: boolean;
}

export const LoadingCard: React.FC<LoadingCardProps> = ({ isPolaroid, showLabel }) => {
    const cardContent = (
         <div className="w-full aspect-square bg-gray-800 rounded-lg flex items-center justify-center">
            <div className="flex flex-col items-center">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-400"></div>
                <p className="text-gray-400 mt-4">Generating...</p>
            </div>
        </div>
    );

    if (isPolaroid) {
        return (
            <div className="bg-white p-4 pb-16 rounded-lg shadow-xl transform rotate-[-3deg]">
                {cardContent}
                 {showLabel && <div className="absolute bottom-6 left-0 right-0 text-center"><div className="h-6 bg-gray-300 rounded-md w-3/4 mx-auto animate-pulse"></div></div>}
            </div>
        );
    }

    return (
         <div className="relative group">
            {cardContent}
            {showLabel && <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 h-6 bg-gray-700 rounded-md w-24 animate-pulse"></div>}
        </div>
    );
};
