
import React, { useState, useEffect } from 'react';
// @ts-ignore
import { AnimatePresence, motion } from 'framer-motion';
import { IconX, IconSparkles } from './icons';
import { upscaleImage } from '../services/geminiService';

interface UpscaleModalProps {
    isOpen: boolean;
    onClose: () => void;
    imageToUpscale: { url: string; index: number, resolution: '2K' | '4K' } | null;
    onConfirmUpscale: (newImageUrl: string, index: number) => void;
}

export const UpscaleModal: React.FC<UpscaleModalProps> = ({ isOpen, onClose, imageToUpscale, onConfirmUpscale }) => {
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const performUpscale = async () => {
            if (!imageToUpscale) return;
            setError(null);
            try {
                const [header, base64Data] = imageToUpscale.url.split(',');
                const mimeType = header.match(/:(.*?);/)?.[1] || 'image/png';
                const newImageUrl = await upscaleImage(base64Data, mimeType, imageToUpscale.resolution);
                onConfirmUpscale(newImageUrl, imageToUpscale.index);
            } catch (err) {
                setError(`Sorry, we couldn't upscale that image. Please try again.`);
                console.error(err);
            }
        };

        if (isOpen && imageToUpscale) {
            performUpscale();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isOpen, imageToUpscale]);

    return (
        <AnimatePresence>
            {isOpen && imageToUpscale && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
                    onClick={onClose}
                >
                    <motion.div
                        initial={{ scale: 0.9, y: 20 }}
                        animate={{ scale: 1, y: 0 }}
                        exit={{ scale: 0.9, y: 20 }}
                        className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-xl text-center p-8 shadow-2xl"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="absolute top-4 right-4">
                            <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700 transition-colors"><IconX /></button>
                        </div>
                        <div className="flex justify-center text-yellow-400 mb-6">
                            <IconSparkles className="w-16 h-16" />
                        </div>
                        <h2 className="text-3xl font-bold text-white mb-3">Enhancing Your Image</h2>
                        <p className="text-gray-400 mb-6">Our AI is working its magic to upscale your photo to {imageToUpscale.resolution}. Please wait a moment...</p>

                        <div className="relative w-full h-80 bg-gray-800 rounded-lg overflow-hidden flex items-center justify-center">
                            <img src={imageToUpscale.url} alt="Image to upscale" className="w-full h-full object-contain blur-sm opacity-50" />
                            <div className="absolute inset-0 flex items-center justify-center flex-col">
                                {error ? (
                                    <p className="text-red-400 text-lg font-semibold">{error}</p>
                                ) : (
                                    <>
                                        <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-b-4 border-yellow-400"></div>
                                        <p className="mt-4 text-white font-semibold">Upscaling...</p>
                                    </>
                                )}
                            </div>
                        </div>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};
