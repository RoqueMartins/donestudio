
import React from 'react';

interface TemplateCardProps {
    id: string;
    name: string;
    icon: React.ReactNode;
    description: string;
    isSelected: boolean;
    onSelect: (id: string) => void;
}

export const TemplateCard: React.FC<TemplateCardProps> = ({ id, name, icon, isSelected, onSelect }) => {
    const baseClasses = "group relative w-full aspect-square p-4 rounded-xl border-2 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-300";
    const selectedClasses = "bg-yellow-400/20 border-yellow-400 text-yellow-300 scale-105 shadow-lg shadow-yellow-500/10";
    const defaultClasses = "bg-gray-800 border-gray-700 hover:border-gray-600 hover:bg-gray-700/50 text-gray-400";
    
    return (
        <div onClick={() => onSelect(id)} className={`${baseClasses} ${isSelected ? selectedClasses : defaultClasses}`}>
            <div className={`transition-transform duration-300 ${isSelected ? 'scale-110' : 'group-hover:scale-110'}`}>{icon}</div>
            <h3 className="mt-3 font-bold text-sm text-white">{name}</h3>
        </div>
    );
};
