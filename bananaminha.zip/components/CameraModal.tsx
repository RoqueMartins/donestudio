
import React, { useRef, useEffect, useState } from 'react';
// @ts-ignore
import { AnimatePresence, motion } from 'framer-motion';
import { Button } from './Button';
import { IconCamera, IconX, IconRefresh } from './icons';

interface CameraModalProps {
    isOpen: boolean;
    onClose: () => void;
    onCapture: (imageDataUrl: string) => void;
}

export const CameraModal: React.FC<CameraModalProps> = ({ isOpen, onClose, onCapture }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [capturedImage, setCapturedImage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const startCamera = async () => {
        try {
            const mediaStream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: 'user' },
                audio: false,
            });
            setStream(mediaStream);
            if (videoRef.current) {
                videoRef.current.srcObject = mediaStream;
            }
            setError(null);
        } catch (err) {
            console.error("Error accessing camera:", err);
            setError("Could not access the camera. Please check your browser permissions.");
        }
    };

    const stopCamera = () => {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            setStream(null);
        }
    };

    useEffect(() => {
        if (isOpen) {
            startCamera();
        } else {
            stopCamera();
            setCapturedImage(null);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isOpen]);

    const handleCapture = () => {
        if (videoRef.current && canvasRef.current) {
            const video = videoRef.current;
            const canvas = canvasRef.current;
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const context = canvas.getContext('2d');
            if (context) {
                context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
                setCapturedImage(canvas.toDataURL('image/png'));
                stopCamera();
            }
        }
    };

    const handleConfirm = () => {
        if (capturedImage) {
            onCapture(capturedImage);
            onClose();
        }
    };
    
    const handleRetake = () => {
        setCapturedImage(null);
        startCamera();
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
                    onClick={onClose}
                >
                    <motion.div
                        initial={{ scale: 0.9, y: 20 }}
                        animate={{ scale: 1, y: 0 }}
                        exit={{ scale: 0.9, y: 20 }}
                        className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-2xl p-6 shadow-2xl"
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="flex justify-between items-center mb-4">
                            <h2 className="text-2xl font-bold text-white">Use Camera</h2>
                            <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-700 transition-colors"><IconX/></button>
                        </div>
                        <div className="relative w-full aspect-video bg-gray-800 rounded-lg overflow-hidden flex items-center justify-center">
                            {error && <p className="text-red-400 p-4 text-center">{error}</p>}
                            <video ref={videoRef} autoPlay playsInline className={`w-full h-full object-cover ${capturedImage ? 'hidden' : 'block'}`} />
                            {capturedImage && (
                                <img src={capturedImage} alt="Captured photo" className="w-full h-full object-cover" />
                            )}
                             <canvas ref={canvasRef} className="hidden" />
                        </div>
                        <div className="mt-6 flex justify-center gap-4">
                           {capturedImage ? (
                                <>
                                    <Button onClick={handleRetake}><div className="flex items-center gap-2"><IconRefresh/><span>Retake</span></div></Button>
                                    <Button onClick={handleConfirm} primary>Confirm Photo</Button>
                                </>
                           ) : (
                                <Button onClick={handleCapture} primary disabled={!stream}>
                                   <div className="flex items-center gap-2"><IconCamera/><span>Capture</span></div>
                                </Button>
                           )}
                        </div>
                    </motion.div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};
