
import React from 'react';
// @ts-ignore
import { AnimatePresence, motion } from 'framer-motion';
import { IconX, IconAlert } from './icons';

interface ErrorNotificationProps {
    message: string | null;
    onDismiss: () => void;
}

export const ErrorNotification: React.FC<ErrorNotificationProps> = ({ message, onDismiss }) => {
    return (
        <AnimatePresence>
            {message && (
                <motion.div
                    initial={{ opacity: 0, y: -50 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -50, transition: { duration: 0.2 } }}
                    className="fixed top-5 left-1/2 -translate-x-1/2 z-50 w-full max-w-md"
                >
                    <div className="bg-red-500/90 backdrop-blur-sm text-white font-semibold rounded-xl shadow-2xl p-4 flex items-start gap-4 mx-4">
                        <div className="flex-shrink-0 pt-0.5">
                            <IconAlert className="w-6 h-6"/>
                        </div>
                        <div className="flex-grow">
                            {message}
                        </div>
                        <button onClick={onDismiss} className="p-1 rounded-full hover:bg-white/20 transition-colors flex-shrink-0">
                            <IconX className="w-5 h-5"/>
                        </button>
                    </div>
                </motion.div>
            )}
        </AnimatePresence>
    );
};
