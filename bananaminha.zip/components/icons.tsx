
import React from 'react';

const Icon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props} />
);

export const IconCamera: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <Icon {...props}><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z" /><circle cx="12" cy="13" r="3" /></Icon>
);

export const IconDownload: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <Icon {...props}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" /></Icon>
);

export const IconPlus: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <Icon {...props}><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></Icon>
);

export const IconSparkles: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <Icon {...props}><path d="M12 2L9.5 9.5 2 12l7.5 2.5L12 22l2.5-7.5L22 12l-7.5-2.5L12 2z" /><path d="M5 2v4" /><path d="M19 2v4" /><path d="M5 20v-4" /><path d="M19 20v-4" /></Icon>
);

export const IconUpload: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <Icon {...props} className="w-12 h-12 mb-3"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="17 8 12 3 7 8" /><line x1="12" y1="3" x2="12" y2="15" /></Icon>
);

export const IconX: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <Icon {...props} className="w-5 h-5"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></Icon>
);

export const IconRefresh: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <Icon {...props}><polyline points="23 4 23 10 17 10" /><polyline points="1 20 1 14 7 14" /><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" /></Icon>
);

export const IconWand: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <Icon {...props}><path d="M15 4V2" /><path d="M15 10v-2" /><path d="M15 16v-2" /><path d="M19 6.5 21 5" /><path d="M19 12.5 21 11" /><path d="m3 21 9-9" /><path d="M12.5 19 14 20.5" /><path d="m6.5 13-1.5 1.5" /><path d="M3 7.5 4.5 9" /><path d="M9 2.5 10.5 4" /><path d="m14 5 6 6" /></Icon>
);

export const IconAlert: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <Icon {...props}><circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" /></Icon>
);

export const IconChevronDown: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <Icon {...props}><polyline points="6 9 12 15 18 9" /></Icon>
);

// Template Icons
const TemplateIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...props} />
);

export const IconDecades: React.FC = () => <TemplateIcon><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></TemplateIcon>;
export const IconLookbook: React.FC = () => <TemplateIcon><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></TemplateIcon>;
export const IconHeadshot: React.FC = () => <TemplateIcon><path d="M5.52 19c.64-2.2 1.84-3 3.22-3h6.52c1.38 0 2.58.8 3.22 3"/><circle cx="12" cy="10" r="3"/><circle cx="12" cy="12" r="10"/></TemplateIcon>;
export const IconMall: React.FC = () => <TemplateIcon><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/><path d="M12 7v5"/></TemplateIcon>;
export const IconSelfie: React.FC = () => <TemplateIcon><path d="M12 12a5 5 0 0 1 5 5"/><path d="M12 8a9 9 0 0 1 9 9"/><path d="M17 12a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1h2z"/><path d="m2 14 3-3h5"/><path d="m11 11-3 3"/></TemplateIcon>;
export const IconHair: React.FC = () => <TemplateIcon><path d="M2 13s4-5 4-9a4 4 0 0 1 8 0c0 4 4 9 4 9"/><path d="M12 13a4 4 0 0 0 0 8h0a4 4 0 0 0 0-8h0Z"/><path d="M17.5 14.5a2.5 2.5 0 0 0 0 5h0a2.5 2.5 0 0 0 0-5h0Z"/><path d="M6.5 14.5a2.5 2.5 0 0 1 0 5h0a2.5 2.5 0 0 1 0-5h0Z"/></TemplateIcon>;
export const IconFigurine: React.FC = () => <TemplateIcon><path d="M14.5 12c0-2.5-.5-5-2.5-5-2.5 0-2.5 5 0 5"/><path d="M20 12c0-2.5-.5-5-2.5-5-2.5 0-2.5 5 0 5"/><path d="M4 12c0-2.5-.5-5-2.5-5C-1 7 .5 12 4 12Z"/><path d="M9.5 12c0-2.5-.5-5-2.5-5-2.5 0-2.5 5 0 5"/><path d="M12 14v8"/><path d="M9 22h6"/><path d="M12 3a1 1 0 0 0-1 1v3a1 1 0 0 0 2 0V4a1 1 0 0 0-1-1Z"/></TemplateIcon>;
export const IconSwimsuit: React.FC = () => <TemplateIcon><path d="M2 22c.6-2 1.6-4 3-5s3-2 5-2 3.5 1 5 2 2.4 3 3 5"/><path d="m12.5 12-2-6-2 6h4Z"/><path d="M10 12c-2.5 1-3 3.5-3 3.5"/><path d="M14 12c2.5 1 3 3.5 3 3.5"/><path d="M4 16.5c-1.5 0-3 .5-3 2.5"/><path d="M20 16.5c1.5 0 3 .5 3 2.5"/></TemplateIcon>;

