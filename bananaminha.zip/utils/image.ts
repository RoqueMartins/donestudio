
export const toBase64 = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (error) => reject(error);
    });

export const triggerDownload = async (imageUrl: string, fileName: string) => {
    const a = document.createElement('a');
    a.href = imageUrl;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
};

const loadImage = (url: string): Promise<HTMLImageElement> =>
    new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = url;
        img.onload = () => resolve(img);
        img.onerror = (err) => reject(err);
    });

export const cropImage = async (imageUrl: string, targetRatio: '1:1' | '9:16'): Promise<string> => {
    const img = await loadImage(imageUrl);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;

    const originalWidth = img.width;
    const originalHeight = img.height;
    const originalRatio = originalWidth / originalHeight;
    const finalRatio = targetRatio === '1:1' ? 1 : 9 / 16;

    let cropWidth, cropHeight, cropX, cropY;

    if (originalRatio > finalRatio) {
        // Original is wider than target, crop width
        cropHeight = originalHeight;
        cropWidth = originalHeight * finalRatio;
        cropX = (originalWidth - cropWidth) / 2;
        cropY = 0;
    } else {
        // Original is taller than target, crop height
        cropWidth = originalWidth;
        cropHeight = originalWidth / finalRatio;
        cropY = (originalHeight - cropHeight) / 2;
        cropX = 0;
    }
    
    canvas.width = cropWidth;
    canvas.height = cropHeight;

    ctx.drawImage(img, cropX, cropY, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);
    return canvas.toDataURL('image/png');
};


export const createSingleFramedImage = async (imageUrl: string, ratio: '1:1' | '9:16', label: string | null): Promise<string> => {
    const croppedUrl = await cropImage(imageUrl, ratio);
    const img = await loadImage(croppedUrl);
    
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;

    const padding = img.width * 0.05;
    const bottomPadding = label ? img.width * 0.18 : padding;
    
    canvas.width = img.width + padding * 2;
    canvas.height = img.height + padding + bottomPadding;
    
    ctx.fillStyle = '#FFFFFF';
    ctx.shadowColor = 'rgba(0,0,0,0.3)';
    ctx.shadowBlur = 20;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 10;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.shadowColor = 'transparent';

    ctx.drawImage(img, padding, padding, img.width, img.height);
    
    if (label) {
        const fontSize = Math.max(24, Math.floor(img.width * 0.08));
        ctx.font = `700 ${fontSize}px Caveat, cursive`;
        ctx.fillStyle = 'rgba(0,0,0,0.8)';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(label, canvas.width / 2, img.height + padding + bottomPadding / 2);
    }
    
    return canvas.toDataURL('image/png');
};
