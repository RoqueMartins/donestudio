
import { GoogleGenAI, GenerateContentResponse, Modality } from "@google/genai";
import { TemplateId, Prompt } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const buildPrompt = (
    template: TemplateId, 
    prompt: Prompt, 
    options: any
): string => {
    let basePrompt = `A high-resolution, photorealistic image.`;

    switch (template) {
        case 'headshots':
            basePrompt += ` A professional headshot of a person ${prompt.clothing} ${prompt.background}. They have a ${options.headshotExpression} and are posed facing ${options.headshotPose}. The lighting is flattering and professional.`;
            break;
        case 'styleLookbook':
            const style = options.lookbookStyle === 'Other' ? options.customLookbookStyle : options.lookbookStyle;
            basePrompt += ` ${prompt.base} The style is ${style}.`;
            break;
        case 'hairStyler':
            let hairPrompt = ` The photo should be a high-quality portrait focusing on the person's hair. The hairstyle is: ${prompt.base}.`;
            if (options.hairColors.length > 0) {
                hairPrompt += ` The primary hair color is ${options.hairColors[0]}`;
                if (options.hairColors.length > 1) {
                    hairPrompt += `, with ${options.hairColors[1]} highlights.`;
                } else {
                    hairPrompt += `.`;
                }
            }
            basePrompt += hairPrompt;
            break;
        case 'eightiesMall':
            basePrompt += ` ${prompt.base} The photo has a distinctive, over-saturated, slightly faded 80s aesthetic. Photoshoot style: ${options.currentAlbumStyle}.`;
            break;
        default:
            basePrompt += ` ${prompt.base}.`;
            break;
    }
    return basePrompt + " Maintain the person's facial features and identity from the provided image.";
};

const extractImage = (response: GenerateContentResponse): string | null => {
    for (const candidate of response.candidates) {
        for (const part of candidate.content.parts) {
            if (part.inlineData) {
                const base64Image = part.inlineData.data;
                const mimeType = part.inlineData.mimeType;
                return `data:${mimeType};base64,${base64Image}`;
            }
        }
    }
    return null;
};

export const generateImage = async (
    base64Data: string,
    mimeType: string,
    template: TemplateId,
    prompt: Prompt,
    options: any
): Promise<string> => {
    const fullPrompt = buildPrompt(template, prompt, options);

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: {
                parts: [
                    { inlineData: { data: base64Data, mimeType: mimeType } },
                    { text: fullPrompt },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });

        const imageUrl = extractImage(response);
        if (!imageUrl) {
            throw new Error("API did not return an image.");
        }
        return imageUrl;

    } catch (error) {
        console.error("Error generating image with Gemini:", error);
        throw new Error("Failed to generate image. Please check the console for more details.");
    }
};

export const generateDynamicPrompt = async (prompt: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating dynamic prompt:", error);
        throw new Error("Failed to generate dynamic prompt.");
    }
};

export const editImage = async (base64Data: string, mimeType: string, prompt: string): Promise<string> => {
     try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: {
                parts: [
                    { inlineData: { data: base64Data, mimeType: mimeType } },
                    { text: prompt },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });
        
        const imageUrl = extractImage(response);
        if (!imageUrl) {
            throw new Error("API did not return an image after editing.");
        }
        return imageUrl;

    } catch (error) {
        console.error("Error editing image with Gemini:", error);
        throw new Error("Failed to edit image.");
    }
};

export const upscaleImage = async (base64Data: string, mimeType: string, resolution: '2K' | '4K'): Promise<string> => {
    const prompt = `Upscale this image to ${resolution} resolution. Enhance details, sharpness, and clarity while preserving the original content and photorealism. Do not add or change any elements in the image.`;
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image-preview',
            contents: {
                parts: [
                    { inlineData: { data: base64Data, mimeType: mimeType } },
                    { text: prompt },
                ],
            },
            config: {
                responseModalities: [Modality.IMAGE, Modality.TEXT],
            },
        });
        
        const imageUrl = extractImage(response);
        if (!imageUrl) {
            throw new Error("API did not return an upscaled image.");
        }
        return imageUrl;

    } catch (error) {
        console.error("Error upscaling image with Gemini:", error);
        throw new Error("Failed to upscale image.");
    }
};
